from admin1 import Admin
from book1 import Book
from member1 import Member
from borrow1 import Borrow
from history1 import History
from db import init_db

def main():
    init_db()
    admin = Admin()
    if not admin.login():
        print("Incorrect password. Exiting.")
        return

    while True:
        print("\nLIBRARY MANAGEMENT SYSTEM")
        print("1. Add Book")
        print("2. View Books")
        print("3. Filter Books by Genre")
        print("4. Add Member")
        print("5. View Members")
        print("6. Borrow Book")
        print("7. Return Book")
        print("8. View All History")
        print("9. View Member Fine")
        print("0. Exit")

        choice = input("Choose an option: ")

        if choice == "1":
            Book.add_book()
        elif choice == "2":
            Book.view_books()
        elif choice == "3":
            Book.filter_books_by_genre()
        elif choice == "4":
            Member.add_member()
        elif choice == "5":
            Member.view_members()
        elif choice == "6":
            Borrow.borrow_book()
        elif choice == "7":
            Borrow.return_book()
        elif choice == "8":
            History.view_all()
        elif choice == "9":
            Member.view_fine()
        elif choice == "0":
            print("Exiting.")
            break
        else:
            print("Invalid choice.")

if __name__ == "__main__":
    main()
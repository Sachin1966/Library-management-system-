from database import get_connection

class Member:
    @staticmethod
    def add_member():
        name = input("Enter name: ")
        with get_connection() as conn:
            conn.execute("INSERT INTO members (name) VALUES (?)", (name,))
            print(f"Member '{name}' added.")

    @staticmethod
    def view_members():
        with get_connection() as conn:
            for row in conn.execute("SELECT * FROM members"):
                print(f"ID: {row[0]}, Name: {row[1]}, Fine: ₹{row[2]}")

    @staticmethod
    def view_fine():
        member_id = int(input("Enter Member ID: "))
        with get_connection() as conn:
            cur = conn.execute("SELECT name, fine FROM members WHERE id=?", (member_id,))
            row = cur.fetchone()
            if row:
                print(f"Member '{row[0]}' has fine: ₹{row[1]}")
            else:
                print("Member not found.")
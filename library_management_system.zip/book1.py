from database import get_connection

class Book:
    @staticmethod
    def add_book():
        title = input("Title: ")
        author = input("Author: ")
        genre = input("Genre: ")
        with get_connection() as conn:
            conn.execute("INSERT INTO books (title, author, genre) VALUES (?, ?, ?)", (title, author, genre))
            print(f"Book '{title}' added.")

    @staticmethod
    def view_books():
        with get_connection() as conn:
            for row in conn.execute("SELECT * FROM books"):
                status = "Available" if row[4] else "Borrowed"
                print(f"{row[0]}: {row[1]} by {row[2]} - {row[3]} - {status}")

    @staticmethod
    def filter_books_by_genre():
        genre = input("Enter genre: ").lower()
        with get_connection() as conn:
            found = False
            for row in conn.execute("SELECT * FROM books WHERE LOWER(genre)=?", (genre,)):
                status = "Available" if row[4] else "Borrowed"
                print(f"{row[0]}: {row[1]} by {row[2]} - {status}")
                found = True
            if not found:
                print("No books in this genre.")
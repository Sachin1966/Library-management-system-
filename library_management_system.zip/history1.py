from database import get_connection

class History:
    @staticmethod
    def view_all():
        with get_connection() as conn:
            for row in conn.execute("SELECT * FROM history"):
                print(row)
from database import get_connection
import datetime

class Borrow:
    @staticmethod
    def borrow_book():
        member_id = int(input("Member ID: "))
        book_id = int(input("Book ID: "))
        with get_connection() as conn:
            cur = conn.execute("SELECT available FROM books WHERE id=?", (book_id,))
            book = cur.fetchone()
            if not book or not book[0]:
                print("Book not available.")
                return
            conn.execute("UPDATE books SET available=0 WHERE id=?", (book_id,))
            conn.execute("INSERT INTO borrowed (book_id, member_id, date_borrowed) VALUES (?, ?, ?)",
                         (book_id, member_id, datetime.date.today()))
            print("Book borrowed.")

    @staticmethod
    def return_book():
        book_id = int(input("Book ID to return: "))
        with get_connection() as conn:
            conn.execute("UPDATE books SET available=1 WHERE id=?", (book_id,))
            conn.execute("DELETE FROM borrowed WHERE book_id=?", (book_id,))
            print("Book returned.")
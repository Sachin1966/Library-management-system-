import hashlib

ADMIN_PASSWORD_HASH = hashlib.sha256("admin123".encode()).hexdigest()

class Admin:
    def login(self):
        password = input("Enter admin password: ")
        return hashlib.sha256(password.encode()).hexdigest() == ADMIN_PASSWORD_HASH